Test Automation Approach:

UI Testing Tool: Cypress
Programming Language: JavaScript
Design Pattern: Page Objects
Unit Testing Framework: Jest
Reporting: Mocha Awesome
ScreenShot: Yes
Video: Yes

/* 
Install the following
Cypress, 
Jest, 
Mocha Awesome
*/

Execution: (npm bin)/cypress run
