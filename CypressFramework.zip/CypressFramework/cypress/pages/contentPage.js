/// <reference types="Cypress" />
import basePage from './basePage';
const contentPage = {
    url: '/express-apps/chart/',
    dataTable: '.edit-items-table',
    deleteBtn: '.delete-button',
    chartTitle: '#chart-title',
    addItemBtn: '.add-item-button',
    previewContainer: '.preview-container',
    itemType: '.item-label-input',
    itemValue: '.item-value-input',
    designTab: '[data-value="design"]',
    barChart: '[data-value="bar-chart"]',

    /**
    * deletes all the rows present in the table
    * @param  nil
    */
    deleteAllRowsInTable() {
        var tableRowCount = 0;
        tableRowCount = Cypress.$('.edit-items-table tbody > tr').length
        console.log("tableRowCount " + tableRowCount)
        for (var i = 0; i < tableRowCount - 1; i++) {
            cy.get(this.dataTable).find('td').eq(4).click();
            cy.get(this.previewContainer).click();
        }
    },

    /**
    * adds chart title
    * @param  {string} chartTitle
    */
    addChartTitle(chartTitle) {
        return cy.get(this.chartTitle).clear().type(chartTitle);
    },

    /**
    * clicks add item buttom in the table
    * @param  nil
    */
    clickAddItemBtn() {
        return cy.get(this.addItemBtn).click();
    },

    /**
    * adds item value in the table
    * @param  {string} itemTypeValue {integer} rowCount
    */
    addDataItemType(itemTypeValue, rowCount) {
        return cy.get(this.dataTable).find('tr').eq(rowCount).find('td').eq(1).type(itemTypeValue).type('{enter}');
    },

    /**
    * adds item count in the table
    * @param  {string} itemTypeValue {integer} rowCount
    */
    addDataItemCount(itemCountValue, rowCount) {
        return cy.get(this.dataTable).find('tr').eq(rowCount).find('td').eq(3).clear().type(itemCountValue);
    },

    /**
    * selects design tab
    * @param  nil
    */
    selectDesignTab() {
        return cy.get(this.designTab).click();
    },

    /**
    * selects bar chart in design tab
    * @param  nil
    */
    selectBarChart() {
        return cy.get(this.barChart).click();
    },
}
export default { ...basePage, ...contentPage }
