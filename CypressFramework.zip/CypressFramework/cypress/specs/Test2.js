import contentPage from '../pages/contentPage'
var valueArr = [20, 10, 50, 5];
var charTitle = "test2";

describe('Test2', () => {
    it('open the home url', () => {
        contentPage.goto();
        cy.screenshot();
    })

    it('delete all rows', () => {
        contentPage.deleteAllRowsInTable();
        cy.screenshot();
    })

    it('enter chart title as test1', () => {
        contentPage.addChartTitle(charTitle);
        cy.screenshot();
    })

    it('add 4 items', () => {
        for (var i = 0; i < valueArr.length; i++) {
            contentPage.clickAddItemBtn();
            contentPage.addDataItemType("item" + (i + 1), (i + 1));
            contentPage.addDataItemCount(valueArr[i], (i + 1));
            cy.screenshot();
        }
    })

    it('open design tab', () => {
        contentPage.selectDesignTab();
        cy.screenshot();
    })

    it('choose bar chart', () => {
        contentPage.selectBarChart();
        cy.screenshot();
    })

    it('validate the chart that is rendered', () => {
        cy.contains(charTitle);
        cy.screenshot();
    })

})
